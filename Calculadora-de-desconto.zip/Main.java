import java.util.Scanner;

class Main{
public static void main (String[] args){

Scanner entrada = new Scanner (System.in);
  
System.out.println("Digite o valor do produto");
  
double prod = entrada.nextDouble();

System.out.println("Digite o número do desconto");

int desc = entrada.nextInt();
  
double x = prod * desc /100;

double fim = prod - x;

System.out.print("O valor do produto com " +desc+ "% de desconto é "+fim+ " reais");
  }
}